public class Singer {
    private String name;
    private int noOfPerformances;
    private double earnings;
    private Song favSong1;
    private static int totalPerformances;
    
    public Singer(String name){
        this.name = name;
        this.noOfPerformances = 0;
        this.earnings = 0.0;
    }
    public void performForAudience(int audience){
        noOfPerformances++;
        earnings += audience*100;
    }
    
    public void performForAudience(String collab, int audience){
        earnings += (audience*100)/2;
    }
    public void changeFavSong(Song favSong2){
        favSong1 = favSong2;
    }

    public String getName(){
        return name;
    }
    public String getNoOfPerformances(){
        return noOfPerformances;
    }
    public String getEarnings(){
        return earnings;
    }
    public String getFavSong1(){
        return favSong1;
    }
    public int getTotalPerformances(){
        return totalPerformances;
    }

}
