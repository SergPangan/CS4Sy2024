public class Artist {
    private String name;
    private int Albums;
    private int Listen;
    
    public Artist(String name, int Albums, int Listen){
        this.name = name;
        this.Albums = Albums;
        this.Listen = Listen;
    }

    public String getName(){
        return name;
    }
    public String getAlbums(){
        return Albums;
    }
    public String getListen(){
        return Listen;
    }
}
