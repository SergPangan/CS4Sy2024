public class Song {
    private String songName;
    private int songRelease;

    public Song(String songName, int songRelease){
        this.songName = songName;
        this.songRelease = songRelease;
    }
    public String getsongName(){
        return songName;
    }
    public String getsongRelease(){
        return songRelease;
    }
}
