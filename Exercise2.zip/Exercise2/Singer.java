public class Singer {
    String name;
    int noOfPerformances;
    double earnings;
    Song favSong1;
    
    public Singer(String name){
        this.name = name;
        this.noOfPerformances = 0;
        this.earnings = 0.0;
    }
    public void performForAudience(int audience){
        noOfPerformances++;
        earnings += audience*100;
    }
    
    public void changeFavSong(Song favSong2){
        this.favSong1 = favSong2;
    }
}
