public class Song {
    String songName;
    int songRelease;

    public Song(String songName, int songRelease){
        this.songName = songName;
        this.songRelease = songRelease;
    }
}
