public class Exercise1 {

    public static void main(String[] args){
        Artist a1 = new Artist("Mind's Eye", 2, 672372);
        Artist a2 = new Artist("SOS", 1, 109368);
        Artist a3 = new Artist("Eyedress", 9, 12805758);
      
        Song favSong1 = new Song("Dark Red", 2017);
        Song favSong2 = new Song("Infrunami", 2020);
        
        Singer singer = new Singer("Steve Lacy");

        singer.changeFavSong(favSong1);
        singer.performForAudience(12);
        singer.changeFavSong(favSong2);
    }

}