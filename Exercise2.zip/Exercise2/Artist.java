public class Artist {
    String name;
    int Albums;
    int Listen;
    
    public Artist(String name, int Albums, int Listen){
        this.name = name;
        this.Albums = Albums;
        this.Listen = Listen;
    }
}
