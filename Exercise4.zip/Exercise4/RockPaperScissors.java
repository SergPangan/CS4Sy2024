import java.util.Scanner;

public class RockPaperScissors
{
	public static void main(String[] args)
	{
		Move rock = new Move("Rock");
		Move paper = new Move("Paper");
		Move scissors = new Move("Scissors");
		
		rock.setStrongAgainst(scissors);
		paper.setStrongAgainst(rock);
		scissors.setStrongAgainst(paper);
		
		Scanner input = new Scanner(System.in);
		int roundsToWin = 2;
		String userInput;
		int userRounds;
		String userMove;
		
		int userScore = 0;
		int computerScore = 0;
		
		do{
			System.out.println("");
			System.out.println("Welcome to Rock, Paper, Scissors. Please choose an option:");
			System.out.println("1. Start game"); 
			System.out.println("2. Change number of rounds");
			System.out.println("3. Exit application");
			userInput = input.next();
			
			if(userInput.equals("1")){
				System.out.println("");
				System.out.println("This match will be first to " + roundsToWin + " wins.");
				
				while (userScore < roundsToWin && computerScore < roundsToWin){
					System.out.println("");
					System.out.println("The computer has selected its move. Select your move:");
					System.out.println("1. Rock"); 
					System.out.println("2. Paper");
					System.out.println("3. Scissors");
					userMove = input.next();
					System.out.println("");
					int random = (int) Math.floor(Math.random()*3) + 1;
					if(userMove.equals("1")){
						if(random == 1){
						System.out.println("Player chose Rock. Computer chose Rock. Round is tied!" );
						}
						else if(random == 2){
						System.out.println("Player chose Rock. Computer chose Paper. Computer wins round!" );
						computerScore++;
						}
						else if(random == 3){
						System.out.println("Player chose Rock. Computer chose Scissors. Player wins round!" );
						userScore++;
					}
					
				}
				else if(userMove.equals("2")){
					if(random == 1){
					System.out.println("Player chose Paper. Computer chose Rock. Player wins round!" );
					userScore++;
					}
					else if(random == 2){
					System.out.println("Player chose Paper. Computer chose Paper. Round is tied!" );
					}
					else if(random == 3){
					System.out.println("Player chose Paper. Computer chose Scissors. Computer wins round!" );
					computerScore++;
					}
				}
				else if(userMove.equals("3")){
					if(random == 1){
					System.out.println("Player chose Scissors. Computer chose Rock. Computer wins round!" );
					computerScore++;
					}
					else if(random == 2){
					System.out.println("Player chose Scissors. Computer chose Paper. Player wins round!" );
					userScore++;
					}
					else if(random == 3){
					System.out.println("Player chose Scissors. Computer chose Scissors. Round is tied!" );
					}
				}
				System.out.println("Player: " + userScore + " - " + "Computer: " + computerScore);
				}
				userScore = 0;
				computerScore = 0;
				if(userScore > computerScore){
					System.out.println("");
					System.out.println("Player wins!");
				}
				else if(userScore < computerScore){
					System.out.println("");
					System.out.println("Computer wins!");
				}
				
			}
			
			else if(userInput.equals("2")){
			System.out.println("How many wins are needed to win a match?");
			userRounds = input.nextInt();
			roundsToWin = userRounds;
			System.out.println("");
			System.out.println("New setting has been saved!");
			}
			
		}while(userInput.equals("1") || userInput.equals("2"));
		
		System.out.println("");
		System.out.println("Thank you for playing!");
	}
}